# Image-editing
Easiest way of editing images using open CV
